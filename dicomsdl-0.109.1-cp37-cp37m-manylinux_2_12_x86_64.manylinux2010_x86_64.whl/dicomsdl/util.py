# encoding=utf-8

from . import _util

convert_to_uint8 = _util._convert_to_uint8

def apply_window_center():
  print("Hello")